#include "platform.h"
#include "sleep.h"
#include "xstatus.h"
#include "xil_types.h"

#include "xgpio.h"
#include "xsysmon.h"
#include "xparameters.h"

#define LED_CH 1
#define BTN_CH 1

#define BTN0_MASK 0x1

#define GREEN_MIN_SEC 30
#define GREEN_MAX_SEC 60
#define YELLOW_SEC    3

#define TICK_US 100000
#define TICKS_1S 10
#define TICKS_500MS 5

#define POT_VAUX_CH   1
#define LIGHT_VAUX_CH 0
#define DARK_THRESH_12BIT 1200

#ifndef LED_BASEADDR
  #if defined(XPAR_AXI_GPIO_LED_BASEADDR)
    #define LED_BASEADDR XPAR_AXI_GPIO_LED_BASEADDR
  #else
    #define LED_BASEADDR XPAR_XGPIO_1_BASEADDR
  #endif
#endif

#ifndef BTN_BASEADDR
  #if defined(XPAR_AXI_GPIO_BTN_BASEADDR)
    #define BTN_BASEADDR XPAR_AXI_GPIO_BTN_BASEADDR
  #else
    #define BTN_BASEADDR XPAR_XGPIO_0_BASEADDR
  #endif
#endif

#ifndef SYSMON_BASEADDR
  #if defined(XPAR_XSYSMON_0_BASEADDR)
    #define SYSMON_BASEADDR XPAR_XSYSMON_0_BASEADDR
  #else
    #define SYSMON_BASEADDR XPAR_XADC_ADC_BASEADDR
  #endif
#endif

static XGpio   GpioLeds;
static XGpio   GpioBtns;
static XSysMon SysMon;

static const u32 RED_G0 = (1u<<0) | (1u<<2);
static const u32 RED_G1 = (1u<<1) | (1u<<3);

static void set_leds(u32 mask){
    XGpio_DiscreteWrite(&GpioLeds, LED_CH, mask & 0xF);
}

static int btn0_edge(void){
    static u32 prev = 0;
    u32 now = XGpio_DiscreteRead(&GpioBtns, BTN_CH) & BTN0_MASK;
    int r = (now && !prev);
    prev = now;
    return r;
}

static u16 to12(u16 raw16){
    return (raw16 >> 4) & 0x0FFF;
}

static u16 read_vaux_raw(int ch){
    return XSysMon_GetAdcData(&SysMon, XSM_CH_AUX_MIN + ch);
}

static int pot_to_seconds_inverse(u16 pot12){
    long span = (long)(GREEN_MAX_SEC - GREEN_MIN_SEC);
    long val  = GREEN_MAX_SEC - ((long)pot12 * span) / 4095L;
    if (val < GREEN_MIN_SEC) val = GREEN_MIN_SEC;
    if (val > GREEN_MAX_SEC) val = GREEN_MAX_SEC;
    return (int)val;
}

static void show_state(int phase){
    set_leds(phase ? RED_G1 : RED_G0);
}

static void yellow_blink_to_next(int next_phase, int blink){
    u32 next_red = next_phase ? RED_G1 : RED_G0;
    set_leds(blink ? next_red : 0);
}

static void night_blink(int blink){
    set_leds(blink ? 0xF : 0x0);
}

static int init_all(void){
    XGpio_Config gcfg;
    XSysMon_Config scfg;

    gcfg.BaseAddress = LED_BASEADDR;
    if (XGpio_CfgInitialize(&GpioLeds, &gcfg, gcfg.BaseAddress) != XST_SUCCESS) return XST_FAILURE;
    XGpio_SetDataDirection(&GpioLeds, LED_CH, 0x0);

    gcfg.BaseAddress = BTN_BASEADDR;
    if (XGpio_CfgInitialize(&GpioBtns, &gcfg, gcfg.BaseAddress) != XST_SUCCESS) return XST_FAILURE;
    XGpio_SetDataDirection(&GpioBtns, BTN_CH, 0xF);

    scfg.BaseAddress = SYSMON_BASEADDR;
    if (XSysMon_CfgInitialize(&SysMon, &scfg, scfg.BaseAddress) != XST_SUCCESS) return XST_FAILURE;

    XSysMon_Reset(&SysMon);
    XSysMon_SetSequencerMode(&SysMon, XSM_SEQ_MODE_SAFE);

    u32 en = 0;
    en |= (XSM_SEQ_CH_AUX00 << POT_VAUX_CH);
    // en |= (XSM_SEQ_CH_AUX00 << LIGHT_VAUX_CH);

    XSysMon_SetSeqChEnables(&SysMon, en);
    XSysMon_SetSequencerMode(&SysMon, XSM_SEQ_MODE_CONTINPASS);

    return XST_SUCCESS;
}

int main(void){
    init_platform();
    if (init_all() != XST_SUCCESS) return 1;

    typedef enum { S_GREEN, S_YELLOW, S_NIGHT } state_t;
    state_t st = S_GREEN;

    int phase = 0;
    int next_phase = 1;
    int remaining = GREEN_MAX_SEC;

    int blink = 0, t500 = 0, t1s = 0;

    while(1){
        usleep(TICK_US);

        if (++t500 >= TICKS_500MS){ t500 = 0; blink = !blink; }

        int one_sec = 0;
        if (++t1s >= TICKS_1S){ t1s = 0; one_sec = 1; }

        u16 pot12   = to12(read_vaux_raw(POT_VAUX_CH));
        // u16 light12 = to12(read_vaux_raw(LIGHT_VAUX_CH));

        int t_green = pot_to_seconds_inverse(pot12);

        if (btn0_edge() && remaining > GREEN_MIN_SEC)
            remaining = GREEN_MIN_SEC;

        // if (light12 < DARK_THRESH_12BIT){
        //     st = S_NIGHT;
        // } else if (st == S_NIGHT){
        //     st = S_GREEN;
        //     remaining = t_green;
        // }

        switch(st){
        case S_NIGHT:
            night_blink(blink);
            break;

        case S_GREEN:
            show_state(phase);
            if (one_sec){
                if (remaining <= 0){
                    st = S_YELLOW;
                    remaining = YELLOW_SEC;
                    next_phase = phase ^ 1;
                } else remaining--;
            }
            break;

        case S_YELLOW:
            yellow_blink_to_next(next_phase, blink);
            if (one_sec){
                if (remaining <= 0){
                    phase = next_phase;
                    st = S_GREEN;
                    remaining = t_green;
                } else remaining--;
            }
            break;
        }
    }
}
