# 2026-01-20T21:39:11.483220500
import vitis

client = vitis.create_client()
client.set_workspace(path="D:/UTCN/An3/SSC/Proiect_Sistem_de_control_al_semaforului_inteligent/PROIECTV10")

platform = client.create_platform_component(name = "platform",hw_design = "D:/UTCN/An3/SSC/Proiect_Sistem_de_control_al_semaforului_inteligent/PROIECTV10/design_1_wrapper.xsa",os = "standalone",cpu = "ps7_cortexa9_0",domain_name = "standalone_ps7_cortexa9_0")

platform = client.get_component(name="platform")
status = platform.build()

comp = client.create_app_component(name="app",platform = "D:/UTCN/An3/SSC/Proiect_Sistem_de_control_al_semaforului_inteligent/PROIECTV10/platform/export/platform/platform.xpfm",domain = "standalone_ps7_cortexa9_0",template = "hello_world")

status = platform.build()

comp = client.get_component(name="app")
comp.build()

vitis.dispose()

